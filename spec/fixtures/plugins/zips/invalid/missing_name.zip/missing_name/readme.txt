
=== Plugin Name === 
Contributors: acobot                     
Tags: chat, live chat, live support, live help, customer help, customer service, customer support, online support, bot, chatbot, chat bot, robot, AI, NLP, automation, automated, sales automation, conversion optimization, admin, api, automatic, comment, comments, community, contact,ecommerce, e-commerce, form, free, embed, integration, javascript, jquery, langauge, manage, media, navigation, plugin, plugins, sidebar, social, text, widget, widgets
Requires at least: 2.0.2
Tested up to: 3.3.2   
Stable Tag: 1.1.2
 
Enhance your Wordpress with a live chat robot in 3 minutes or less. Boost the online results like never before. It's simple, easy and FREE.
 
== Description ==

Wow your visitors with a bit of A.I.! 

Go to the beach without worrying about your business. This happy, chatty and clever robot will say Hello to the website visitors, answer their questions and turn them into buying clients 24 hours a day, 7 days a week. 

See a free live DEMO on your site - http://acobot.com/demo

Or jump start with it by installing this plugin now. No A.I. knowledge required!

Main website:
http://www.acobot.com/wordpress

IMPORATANT: Acobot is designed to chat in English. The robot does NOT work with any other languages. Sorry but she's too busy to study foreign langauges at this time.

Benefits for your business website:

*   Reach more customers by offering 24/7 live support.
*   Delight them by eliminating wait times.
*   Give helpful answers when they have questions.
*   Increase customer satisfaction, reduce site abandonment, and optimize conversion.

In short, Acobot helps you win more customers.

Benefits for your personal website:

*   Impress your website visitors, effortlessly.
*   Keep them stay on your website (longer time on page).
*   Attract them to come back (more repeating visits).
 
== Installation ==

NOTE: Install Acobot only if your website is in English.
 
1. Put this under plugins folder (/wp-content/plugins).
2. Go to Admin->Plugins and activate the plugin "Acobot Live Chat Robot."
3. Sign up at http://acobot.com/wordpress for an installation key.
4. Back to your website and provide the key.

Your website visitors can then start chatting with the robot immediately.

TROUBLESHOOTING: The chat widget doesn't show? Clear the cache of your WordPress!

What to do next?
Log into http://acobot.com to:

* Train your robot. See http://acobot.com/help.
* View chat log.

We recommend you to read the documentation at http://acobot.com/help to get the most out of your robot.

== Frequently Asked Questions ==

= Can the robot speak xxx language? =
The robot only speaks English at this time. 

= Is Acobot Free? =
Yes, you can use it for free, be your site for commercial or noncommercial purpose.

= Will Free Trial Expire? =
It's not a free trial. It's a FREE plan, which will never expire.

= How do you define "nonecommercial use"? =
If you make money with your website, it's commercial. Don't worry if you're not sure. Just choose an option based on your own judgement and we will review it late.

= Where can I see the chat logs? =
Log on to acobot.com to see the logs.
   
= What is the difference with other Live chat software? =
Acobot = Live Chat Software + Live Chat Robot. It's fully automated. It doesn't require your involvement in chatting.

= Can I customize my robot? =
Sure, you can customize EVERY message sent by the robot. And customization is dead simple. You just chat with her as if you were a client and then teach her as necessary.

= How can I custommiz my robot? =
You can train your robot by chatting with her. It couldn't be easier. For more information, check http://acobot.com/help.

= Can I personally chat with the website visitors? =
No. Acobot doesn't support human live chat agent. It's designed for automated conversation.

= Can I remove Acobot branding =
You can remove the Acobot branding by upgrading to any PRO plans.

== Upgrade Notice ==

== Screenshots ==

1. The widget on the web page after installation.
2. Train your robot by chatting with her.
3. How to get your own installation key.
4. Chat logs.

== Changelog ==

= 1.0 =
First release.  

= 1.1 =
Added ability to use Acobot API for advanced users.

= 1.1.2 =
Improved the configuration page for administrators.

== Support ==
We offer customer support to all Acobot users including FREE plan subscribers.

If you have any questions, comments or suggestions, don't hesitate to contact us at http://acobot.com/contact.

Or drop us a line at support (at) acosys dot com.

Note we allocate resurces to paid users at a higher priority so that they can get the prompt services. Where there are any available resources, we will process the support requests from the free users on a first-in-first-servered basis. Generally you can expect a reply in 24 hours during week day. We appreciate your kind patience in case we unfortunately need more time to process your ticket.



