=== Automated Editor ===
Contributors: woodyhayday
Donate link: http://www.automatededitor.com/compare-versions/
Tags: Post, posts, admin, plugin, replace, search, regex, update, affiliate, links
Requires at least: 2.0.2
Tested up to: 3.2.1
Stable tag: 1.3

Schedule automated editing for your posts and pages, replace strings, regex, append, amend and edit, automatically!

== Description ==

[Automated Editor](http://www.automatededitor.com) add's powerful functionality to your WordPress blog, allowing you to automate editing. Gain complete control of your content and leverage the power of automation to fix, upgrade and supplement your valuable content. Automated editor is the single most powerful replacement for traditional search & replace plugins available. If you wan't to edit right, edit with this, it will replace strings, remove strings, move posts, add to posts, tag posts, untag posts and much more, automatically, working on rules you set up!

**Limited offer @ $35**
**[Upgrade to Ultra Pro Version](http://www.automatededitor.com/compare-versions/)**

[Video Guides](http://www.automatededitor.com/videos/) |
[Screenshots](http://www.automatededitor.com/screenshots/) |
[Compatible With](http://www.automatededitor.com/compatible-with/)|
[Change Log](http://www.automatededitor.com/changelog/) |
[FAQ](http://www.automatededitor.com/faq/)

Features Overview:


* Ultimate search and replace
* Automate content edits
* Use regex to update posts
* Insert affiliate links (high level)
* Automattically add tags
* Automattically add categories
* Import/Export your rules
* Quicker than wordpress filters
* Simple to use
* Designed to be flexible
* Solid & Secure Framework

First 3 Rules and schedule are free and the Ultra Pro version is available @ [Automated Editor.com](http://www.automatededitor.com).

More information:
**[How Automated Editor plugin works](http://www.automatededitor.com/how-does-automated-editor-wordpress-plugin-work/)**


== Installation ==

* Install Automated Editor either via the WordPress.org plugin directory, or by uploading the files to your server.
* Activate Automated Editor plugin from your wordpress plugin screen.
* After activating Automated Editor, you will be able to set up your rules and schedules for automated editing!
* That's it. You're ready to go!

== Frequently Asked Questions ==

For an up to date list of Automated Editor FAQ's see [Automated Editor FAQ's](http://www.automatededitor.com/faq/)

== Screenshots ==

2. Example Schedules
3. Example Rules

== Changelog ==

= 1.3 =
* First Stable public release

= 1.2 =
* Many, Many fixes & improvements

== Upgrade Notice ==

= 1.3 =
All previous versions were not as epic/no public support
